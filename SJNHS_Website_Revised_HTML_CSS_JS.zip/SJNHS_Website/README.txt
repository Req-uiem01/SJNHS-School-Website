# San Jose National High School Website

A responsive SJNHS website template with a PUP-inspired institutional information layout and a green-and-gold visual identity.

## Files
- `index.html` — website structure and content
- `style.css` — responsive styling
- `script.js` — navigation, search, edit mode, image uploads, captions, and backup import/export
- `assets/` — supplied school images

## Run locally
1. Extract the ZIP file.
2. Keep `index.html`, `style.css`, `script.js`, and the `assets` folder together.
3. Open `index.html` in a browser, or use VS Code Live Server.

## Edit website content
1. Click **Edit Content** in the top utility bar.
2. Click a visible heading, paragraph, label, or caption and edit its text.
3. Use the image upload controls to replace supported images.
4. Click outside a text field to save that edit in the current browser.
5. Use **Export Backup** to download a JSON backup of saved text, captions, and uploaded images.
6. Use **Import Backup** to restore a previously exported backup.
7. Click **Reset** only if you want to clear local edits and restore the original template.

## Important publishing limitation
This package is a front-end HTML/CSS/JavaScript template. Its edit mode stores changes in the current browser's `localStorage`; it does not update the website files, publish changes to a server, or synchronize content across different administrators/devices. Uploaded images are stored as browser data and can make the backup file large.

For a real official school website where authorized users can log in and publish shared changes, connect this front end to a school-approved CMS/backend (for example, WordPress, Supabase, or Firebase) and configure authentication, database storage, image storage, backups, and hosting. Do not place private credentials or API keys in front-end JavaScript.

## Before official deployment
Verify all placeholder content with the school administration, including official mission and vision, enrollment information, personnel, programs, policies, office contacts, publications, awards, schedules, and emergency hotlines. Confirm image permissions and photo credits.
